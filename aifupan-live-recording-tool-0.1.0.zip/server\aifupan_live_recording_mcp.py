#!/usr/bin/env python3
"""A safety-scoped local MCP server for the AIFUPAN live-recording workbench.

The server deliberately uses only the local 127.0.0.1 workbench API and
project-local status files.  It never reads, writes, or returns credentials,
webhooks, cookies, stream URLs, or raw notification configuration.
"""

from __future__ import annotations

import ast
import json
import os
import shutil
import sys
import time
from datetime import datetime
from pathlib import Path
from typing import Any
from urllib.error import HTTPError, URLError
from urllib.parse import parse_qsl, urlencode, urlsplit, urlunsplit
from urllib.request import Request, urlopen


SERVER_NAME = "aifupan-live-recording"
SERVER_VERSION = "0.1.0"
DEFAULT_API_BASE = "http://127.0.0.1:8765"
VIDEO_SUFFIXES = {".mp4", ".mkv", ".mov", ".flv", ".ts", ".webm"}
SENSITIVE_KEY_PARTS = ("webhook", "token", "secret", "cookie", "password", "authorization")
SENSITIVE_QUERY_NAMES = {
    "access_token",
    "auth",
    "authorization",
    "cookie",
    "key",
    "password",
    "secret",
    "sign",
    "signature",
    "token",
    "webhook",
}


class ToolError(Exception):
    """An expected, safe error that is shown to the calling AI."""


def _default_project_root() -> Path:
    # <project>/ai-toolkit/<plugin>/server/aifupan_live_recording_mcp.py
    return Path(__file__).resolve().parents[3]


PROJECT_ROOT = Path(os.environ.get("AIFUPAN_RECORDING_ROOT", _default_project_root())).resolve()
RECORDINGS_ROOT = PROJECT_ROOT / "直播录制视频"
MAINTENANCE_DIR = PROJECT_ROOT / "运行数据" / "maintenance"
ENGINE_SOURCE = PROJECT_ROOT / "程序" / "engine" / "src" / "aifupan_engine" / "live_monitor.py"
REPORTER_CONFIG = PROJECT_ROOT / "reporter" / "config" / "reporter_config.json"
API_BASE = os.environ.get("AIFUPAN_RECORDING_API", DEFAULT_API_BASE).rstrip("/")
OUTPUT_WITH_HEADERS = False


def _now_iso() -> str:
    return datetime.now().astimezone().isoformat(timespec="seconds")


def _json_text(value: Any) -> str:
    return json.dumps(value, ensure_ascii=False, indent=2, default=str)


def _must_be_dict(value: Any, label: str = "参数") -> dict[str, Any]:
    if not isinstance(value, dict):
        raise ToolError(f"{label}必须是对象")
    return value


def _must_be_str(value: Any, label: str, *, allow_empty: bool = False, max_length: int = 20_000) -> str:
    if not isinstance(value, str):
        raise ToolError(f"{label}必须是文本")
    text = value.strip()
    if not text and not allow_empty:
        raise ToolError(f"{label}不能为空")
    if len(text) > max_length:
        raise ToolError(f"{label}过长")
    return text


def _optional_str(value: Any, label: str, *, max_length: int = 20_000) -> str | None:
    if value is None:
        return None
    text = _must_be_str(value, label)
    if len(text) > max_length:
        raise ToolError(f"{label}过长")
    return text


def _require_confirm(arguments: dict[str, Any]) -> None:
    if arguments.get("confirm") is not True:
        raise ToolError("这是会改变录屏系统状态的操作；请在确认用户意图后传入 confirm=true。")


def _is_within(path: Path, parent: Path) -> bool:
    try:
        path.resolve().relative_to(parent.resolve())
        return True
    except ValueError:
        return False


def _safe_public_url(value: Any) -> str | None:
    if not isinstance(value, str) or not value.strip():
        return None
    try:
        parsed = urlsplit(value.strip())
    except ValueError:
        return None
    if parsed.scheme not in {"http", "https"}:
        return None
    filtered = [(key, item) for key, item in parse_qsl(parsed.query, keep_blank_values=True) if key.lower() not in SENSITIVE_QUERY_NAMES]
    return urlunsplit((parsed.scheme, parsed.netloc, parsed.path, urlencode(filtered), ""))


def _redact(value: Any, *, key: str = "") -> Any:
    key_lower = key.lower()
    if any(part in key_lower for part in SENSITIVE_KEY_PARTS):
        return "[已隐藏]"
    if isinstance(value, dict):
        return {str(item_key): _redact(item_value, key=str(item_key)) for item_key, item_value in value.items()}
    if isinstance(value, list):
        return [_redact(item) for item in value]
    if isinstance(value, str) and (key_lower.endswith("url") or "url" in key_lower):
        return _safe_public_url(value) or "[已隐藏]"
    return value


def _http_json(method: str, endpoint: str, payload: dict[str, Any] | None = None, timeout: int = 30) -> Any:
    if not endpoint.startswith("/"):
        raise ToolError("内部接口路径不合法")
    url = f"{API_BASE}{endpoint}"
    body = None
    headers = {"Accept": "application/json"}
    if payload is not None:
        body = json.dumps(payload, ensure_ascii=False).encode("utf-8")
        headers["Content-Type"] = "application/json; charset=utf-8"
    request = Request(url, data=body, headers=headers, method=method)
    try:
        with urlopen(request, timeout=timeout) as response:
            raw = response.read().decode("utf-8")
    except HTTPError as exc:
        try:
            detail = exc.read().decode("utf-8", errors="replace")
        except Exception:
            detail = ""
        try:
            safe_detail = _json_text(_redact(json.loads(detail))) if detail else ""
        except json.JSONDecodeError:
            safe_detail = "服务未提供可安全展示的错误详情"
        suffix = f"：{safe_detail}" if safe_detail else ""
        raise ToolError(f"录屏服务返回 HTTP {exc.code}{suffix}") from exc
    except URLError as exc:
        raise ToolError(f"无法连接本机录屏服务：{exc.reason}") from exc
    except TimeoutError as exc:
        raise ToolError("连接本机录屏服务超时") from exc
    try:
        return json.loads(raw)
    except json.JSONDecodeError as exc:
        raise ToolError("录屏服务返回了无法识别的内容") from exc


def _read_json_file(path: Path) -> dict[str, Any]:
    try:
        return json.loads(path.read_text(encoding="utf-8-sig"))
    except FileNotFoundError:
        return {}
    except (OSError, json.JSONDecodeError):
        return {}


def _load_mapping_constant(name: str) -> dict[str, str]:
    try:
        # 引擎源文件在本机以 UTF-8 BOM 保存；utf-8-sig 同时兼容有/无 BOM 的安装包。
        parsed = ast.parse(ENGINE_SOURCE.read_text(encoding="utf-8-sig"), filename=str(ENGINE_SOURCE))
        for node in parsed.body:
            if isinstance(node, ast.Assign):
                if any(isinstance(target, ast.Name) and target.id == name for target in node.targets):
                    value = ast.literal_eval(node.value)
                    if isinstance(value, dict):
                        return {str(key): str(item) for key, item in value.items()}
    except (OSError, SyntaxError, ValueError):
        pass
    return {}


def _source_routes() -> dict[str, Any]:
    folders_by_id = _load_mapping_constant("SOURCE_RECORDING_FOLDERS")
    folders_by_name = _load_mapping_constant("SOURCE_NAME_RECORDING_FOLDERS")
    compressed_by_folder = _load_mapping_constant("SOURCE_COMPRESSED_FOLDERS")
    return {
        "folders_by_id": folders_by_id,
        "folders_by_name": folders_by_name,
        "compressed_by_folder": compressed_by_folder,
    }


def _folder_for_source(source_chat_id: str | None, source_chat_name: str | None) -> tuple[str, str]:
    routes = _source_routes()
    folder_from_id = routes["folders_by_id"].get(source_chat_id or "")
    folder_from_name = routes["folders_by_name"].get(source_chat_name or "")
    if folder_from_id and folder_from_name and folder_from_id != folder_from_name:
        raise ToolError("来源编号与来源名称指向不同项目，已拒绝导入以防目录混放。")
    folder = folder_from_id or folder_from_name
    if not folder:
        raise ToolError("该来源未配置项目目录映射。为避免任务落入默认目录，工具拒绝导入。")
    compressed_folder = routes["compressed_by_folder"].get(folder, "已压缩")
    return folder, compressed_folder


def _expected_paths(folder: str, compressed_folder: str) -> dict[str, str]:
    output = (RECORDINGS_ROOT / folder).resolve()
    compressed = (output / compressed_folder).resolve()
    if not _is_within(output, RECORDINGS_ROOT) or not _is_within(compressed, RECORDINGS_ROOT):
        raise ToolError("项目目录映射越界，已拒绝操作。")
    return {"output_dir": str(output), "compressed_output_dir": str(compressed)}


def _room_summary(entry: dict[str, Any], *, include_homepage_link: bool = True) -> dict[str, Any]:
    room = entry.get("room") if isinstance(entry.get("room"), dict) else {}
    state = entry.get("state") if isinstance(entry.get("state"), dict) else {}
    result = {
        "room_id": room.get("id"),
        "display_name": room.get("display_name") or room.get("manual_name") or room.get("account_name"),
        "account_name": room.get("account_name"),
        "monitor_enabled": room.get("monitor_enabled"),
        "record_enabled": room.get("record_enabled"),
        "quality": room.get("quality"),
        "record_mode": room.get("record_mode"),
        "source_chat_id": room.get("source_chat_id"),
        "source_chat_name": room.get("source_chat_name"),
        "group": room.get("group"),
        "task_id": room.get("task_id"),
        "output_dir": room.get("output_dir"),
        "compressed_output_dir": room.get("compressed_output_dir"),
        "state": {
            "status": state.get("status"),
            "message": state.get("message"),
            "last_checked_at": state.get("last_checked_at"),
            "recording_started_at": state.get("recording_started_at"),
            "recording_finished_at": state.get("recording_finished_at"),
            "current_recording_path": state.get("current_recording_path"),
            "current_recording_file_size": state.get("current_recording_file_size"),
            "last_recording_path": state.get("last_recording_path"),
            "last_recording_file_size": state.get("last_recording_file_size"),
            "recording_valid": state.get("recording_valid"),
            "recording_validation_message": state.get("recording_validation_message"),
            "compression_status": state.get("compression_status"),
            "compressed_recording_path": state.get("compressed_recording_path"),
            "last_error": state.get("last_error"),
        },
    }
    if include_homepage_link:
        result["homepage_url"] = _safe_public_url(room.get("url"))
    return _redact(result)


def _snapshot() -> dict[str, Any]:
    response = _http_json("GET", "/api/live/rooms", timeout=45)
    if not isinstance(response, dict):
        raise ToolError("录屏服务返回的房间快照格式不正确")
    return response


def _find_room(room_id: str) -> dict[str, Any]:
    for entry in _snapshot().get("rooms", []):
        if isinstance(entry, dict) and isinstance(entry.get("room"), dict) and entry["room"].get("id") == room_id:
            return entry
    raise ToolError("没有找到指定录屏房间")


def _number(value: Any, label: str, minimum: float, maximum: float) -> float:
    if isinstance(value, bool) or not isinstance(value, (int, float)):
        raise ToolError(f"{label}必须是数字")
    number = float(value)
    if not minimum <= number <= maximum:
        raise ToolError(f"{label}必须介于 {minimum:g} 和 {maximum:g} 之间")
    return number


def _bool(value: Any, label: str) -> bool:
    if not isinstance(value, bool):
        raise ToolError(f"{label}必须是 true 或 false")
    return value


def tool_get_status(arguments: dict[str, Any]) -> dict[str, Any]:
    health = _http_json("GET", "/api/health", timeout=15)
    snapshot = _snapshot()
    settings = _http_json("GET", "/api/live/settings", timeout=15)
    rooms = [entry for entry in snapshot.get("rooms", []) if isinstance(entry, dict)]
    active = []
    for entry in rooms:
        state = entry.get("state") if isinstance(entry.get("state"), dict) else {}
        if state.get("status") == "recording" or state.get("current_recording_path"):
            active.append(_room_summary(entry))
    response: dict[str, Any] = {
        "checked_at": _now_iso(),
        "project_root": str(PROJECT_ROOT),
        "health": _redact(health),
        "running": snapshot.get("running"),
        "summary": _redact(snapshot.get("summary", {})),
        "recordings_dir": snapshot.get("recordings_dir"),
        "compression": _redact(snapshot.get("compression", {})),
        "segment": _redact(snapshot.get("segment", {})),
        "settings": _redact({
            "recordings_dir": settings.get("recordings_dir"),
            "compress_recordings": settings.get("compress_recordings"),
            "compression_profile": settings.get("compression_profile"),
            "raw_retention": settings.get("raw_retention"),
            "segment_seconds": settings.get("segment_seconds"),
            "archive_sweep_interval_seconds": settings.get("archive_sweep_interval_seconds"),
        }),
        "active_recordings": active,
        "active_recording_count": len(active),
    }
    return response


def tool_list_rooms(arguments: dict[str, Any]) -> dict[str, Any]:
    limit = int(arguments.get("limit", 100))
    if not 1 <= limit <= 200:
        raise ToolError("limit 必须介于 1 和 200 之间")
    query = (_optional_str(arguments.get("query"), "query", max_length=200) or "").casefold()
    source_chat_id = _optional_str(arguments.get("source_chat_id"), "source_chat_id", max_length=200)
    source_chat_name = _optional_str(arguments.get("source_chat_name"), "source_chat_name", max_length=200)
    group = _optional_str(arguments.get("group"), "group", max_length=200)
    status = _optional_str(arguments.get("status"), "status", max_length=100)
    enabled_only = arguments.get("enabled_only", False)
    if not isinstance(enabled_only, bool):
        raise ToolError("enabled_only 必须是 true 或 false")
    include_homepage_link = arguments.get("include_homepage_link", True)
    if not isinstance(include_homepage_link, bool):
        raise ToolError("include_homepage_link 必须是 true 或 false")

    matched: list[dict[str, Any]] = []
    for entry in _snapshot().get("rooms", []):
        if not isinstance(entry, dict):
            continue
        room = entry.get("room") if isinstance(entry.get("room"), dict) else {}
        state = entry.get("state") if isinstance(entry.get("state"), dict) else {}
        searchable = " ".join(str(room.get(key) or "") for key in ("id", "display_name", "account_name", "manual_name", "group", "task_id", "source_chat_name"))
        if query and query not in searchable.casefold():
            continue
        if source_chat_id and room.get("source_chat_id") != source_chat_id:
            continue
        if source_chat_name and room.get("source_chat_name") != source_chat_name:
            continue
        if group and room.get("group") != group:
            continue
        if status and state.get("status") != status:
            continue
        if enabled_only and not (room.get("monitor_enabled") and room.get("record_enabled")):
            continue
        matched.append(_room_summary(entry, include_homepage_link=include_homepage_link))
    return {"count": len(matched), "returned": min(len(matched), limit), "rooms": matched[:limit]}


def tool_get_room(arguments: dict[str, Any]) -> dict[str, Any]:
    room_id = _must_be_str(arguments.get("room_id"), "room_id")
    return _room_summary(_find_room(room_id), include_homepage_link=True)


def tool_describe_routes(arguments: dict[str, Any]) -> dict[str, Any]:
    routes = _source_routes()
    projects = []
    for source_id, folder in routes["folders_by_id"].items():
        compressed_folder = routes["compressed_by_folder"].get(folder, "已压缩")
        projects.append({
            "source_chat_id": source_id,
            "recording_folder": folder,
            **_expected_paths(folder, compressed_folder),
        })
    return {
        "recordings_root": str(RECORDINGS_ROOT),
        "projects": projects,
        "source_name_routes": _redact(routes["folders_by_name"]),
        "safety_rule": "仅已映射来源可以导入；工具不会让已映射来源落入默认目录。",
    }


def tool_import_rooms(arguments: dict[str, Any]) -> dict[str, Any]:
    text = _optional_str(arguments.get("text"), "text") or _optional_str(arguments.get("url"), "url")
    if not text:
        raise ToolError("需要提供 text 或 url")
    source_chat_id = _optional_str(arguments.get("source_chat_id"), "source_chat_id", max_length=200)
    source_chat_name = _optional_str(arguments.get("source_chat_name"), "source_chat_name", max_length=200)
    folder, compressed_folder = _folder_for_source(source_chat_id, source_chat_name)
    expected = _expected_paths(folder, compressed_folder)
    supplied_group = _optional_str(arguments.get("group"), "group", max_length=200)
    if supplied_group and supplied_group != folder:
        raise ToolError("group 与来源映射项目不一致，已拒绝导入。")
    payload: dict[str, Any] = {
        "text": text,
        "source_chat_id": source_chat_id,
        "source_chat_name": source_chat_name,
        "group": folder,
        "monitor_enabled": arguments.get("monitor_enabled", True),
        "record_enabled": arguments.get("record_enabled", True),
        "quality": arguments.get("quality", "OD"),
        "record_mode": arguments.get("record_mode", "video"),
        "auto_analyze": arguments.get("auto_analyze", False),
    }
    for field in ("anchor", "task_id", "submitted_url_raw", "message_text", "raw_text", "raw_message"):
        value = _optional_str(arguments.get(field), field)
        if value is not None:
            payload[field] = value
    for field in ("monitor_enabled", "record_enabled", "auto_analyze"):
        payload[field] = _bool(payload[field], field)
    for field in ("quality", "record_mode"):
        payload[field] = _must_be_str(payload[field], field)
    for field in ("max_minutes", "split_minutes"):
        if field in arguments and arguments[field] is not None:
            payload[field] = _number(arguments[field], field, 0, 24 * 60)

    preview = {
        "project": folder,
        "expected_paths": expected,
        "payload_summary": _redact({key: value for key, value in payload.items() if key not in {"raw_text", "raw_message"}}),
    }
    if arguments.get("dry_run", True) is not False:
        return {"dry_run": True, "will_import": preview, "next_step": "确认无误后使用 dry_run=false 与 confirm=true 再执行。"}
    _require_confirm(arguments)
    result = _http_json("POST", "/api/live/rooms/import", payload, timeout=90)
    rooms = []
    routing_mismatches = []
    for item in result.get("rooms", []) if isinstance(result, dict) else []:
        room_payload = item.get("room") if isinstance(item, dict) and isinstance(item.get("room"), dict) else {}
        room_output = str(room_payload.get("output_dir") or "")
        room_compressed = str(room_payload.get("compressed_output_dir") or "")
        if Path(room_output).resolve() != Path(expected["output_dir"]).resolve() or Path(room_compressed).resolve() != Path(expected["compressed_output_dir"]).resolve():
            routing_mismatches.append(room_payload.get("id"))
        rooms.append({
            "room_id": room_payload.get("id"),
            "display_name": room_payload.get("display_name") or room_payload.get("manual_name") or room_payload.get("account_name"),
            "output_dir": room_output,
            "compressed_output_dir": room_compressed,
        })
    return {
        "dry_run": False,
        "project": folder,
        "expected_paths": expected,
        "imported_count": result.get("count") if isinstance(result, dict) else None,
        "rooms": _redact(rooms),
        "routing_verified": not routing_mismatches,
        "routing_mismatches": routing_mismatches,
    }


def tool_update_room(arguments: dict[str, Any]) -> dict[str, Any]:
    _require_confirm(arguments)
    room_id = _must_be_str(arguments.get("room_id"), "room_id")
    allowed = {
        "display_name", "manual_name", "monitor_enabled", "record_enabled", "quality", "record_mode",
        "max_minutes", "split_minutes", "auto_analyze", "note",
    }
    changes = {key: value for key, value in arguments.items() if key in allowed and value is not None}
    if not changes:
        raise ToolError("没有提供允许修改的房间字段")
    for key in ("display_name", "manual_name", "quality", "record_mode", "note"):
        if key in changes:
            changes[key] = _must_be_str(changes[key], key, allow_empty=(key == "note"))
    for key in ("monitor_enabled", "record_enabled", "auto_analyze"):
        if key in changes:
            changes[key] = _bool(changes[key], key)
    for key in ("max_minutes", "split_minutes"):
        if key in changes:
            changes[key] = _number(changes[key], key, 0, 24 * 60)
    result = _http_json("PATCH", f"/api/live/rooms/{room_id}", changes, timeout=30)
    if not isinstance(result, dict):
        raise ToolError("录屏服务返回的房间更新结果格式不正确")
    return {"updated": True, "room": _room_summary(result)}


def tool_control_room(arguments: dict[str, Any]) -> dict[str, Any]:
    _require_confirm(arguments)
    room_id = _must_be_str(arguments.get("room_id"), "room_id")
    action = _must_be_str(arguments.get("action"), "action")
    paths = {
        "refresh": f"/api/live/rooms/{room_id}/refresh",
        "start_recording": f"/api/live/rooms/{room_id}/record/start",
        "stop_recording": f"/api/live/rooms/{room_id}/record/stop",
    }
    if action not in paths:
        raise ToolError("action 仅支持 refresh、start_recording 或 stop_recording")
    result = _http_json("POST", paths[action], {}, timeout=60)
    return {"room_id": room_id, "action": action, "result": _redact(result)}


def tool_control_monitor(arguments: dict[str, Any]) -> dict[str, Any]:
    _require_confirm(arguments)
    action = _must_be_str(arguments.get("action"), "action")
    if action not in {"start", "stop"}:
        raise ToolError("action 仅支持 start 或 stop")
    result = _http_json("POST", f"/api/live/monitor/{action}", {}, timeout=60)
    return {"action": action, "result": _redact(result)}


def tool_update_settings(arguments: dict[str, Any]) -> dict[str, Any]:
    _require_confirm(arguments)
    allowed = {"compress_recordings", "compression_profile", "raw_retention", "segment_seconds", "archive_sweep_interval_seconds"}
    changes = {key: value for key, value in arguments.items() if key in allowed and value is not None}
    if not changes:
        raise ToolError("没有提供允许修改的全局录制设置")
    if "compress_recordings" in changes:
        changes["compress_recordings"] = _bool(changes["compress_recordings"], "compress_recordings")
    if "compression_profile" in changes:
        changes["compression_profile"] = _must_be_str(changes["compression_profile"], "compression_profile")
    if "raw_retention" in changes:
        changes["raw_retention"] = _must_be_str(changes["raw_retention"], "raw_retention")
        if changes["raw_retention"] not in {"move", "keep"}:
            raise ToolError("raw_retention 仅支持 move 或 keep")
    if "segment_seconds" in changes:
        changes["segment_seconds"] = _number(changes["segment_seconds"], "segment_seconds", 0, 24 * 60 * 60)
    if "archive_sweep_interval_seconds" in changes:
        changes["archive_sweep_interval_seconds"] = _number(changes["archive_sweep_interval_seconds"], "archive_sweep_interval_seconds", 0, 30 * 24 * 60 * 60)
    result = _http_json("PATCH", "/api/live/settings", changes, timeout=60)
    if not isinstance(result, dict):
        raise ToolError("录屏服务返回的设置更新结果格式不正确")
    safe_result = {key: result.get(key) for key in (
        "recordings_dir", "compress_recordings", "compression_profile", "raw_retention",
        "segment_seconds", "archive_sweep_interval_seconds", "completion_events_dir",
    )}
    return {"updated": True, "settings": _redact(safe_result)}


def tool_request_service_restart(arguments: dict[str, Any]) -> dict[str, Any]:
    _require_confirm(arguments)
    MAINTENANCE_DIR.mkdir(parents=True, exist_ok=True)
    flag = MAINTENANCE_DIR / "restart_web_once.flag"
    payload = {"requested_at": _now_iso(), "requested_by": "aifupan-live-recording-mcp", "reason": _optional_str(arguments.get("reason"), "reason", max_length=500) or "维护请求"}
    flag.write_text(_json_text(payload) + "\n", encoding="utf-8")
    return {
        "restart_requested": True,
        "marker_path": str(flag),
        "mechanism": "已交由现有服务看门狗在下一轮安全重启本机网页服务；未另起第二套录屏链。",
    }


def tool_list_recent_files(arguments: dict[str, Any]) -> dict[str, Any]:
    hours = _number(arguments.get("hours", 24), "hours", 1, 24 * 14)
    limit = int(arguments.get("limit", 100))
    if not 1 <= limit <= 500:
        raise ToolError("limit 必须介于 1 和 500 之间")
    group = _optional_str(arguments.get("group"), "group", max_length=200)
    include_zero_byte = arguments.get("include_zero_byte", True)
    if not isinstance(include_zero_byte, bool):
        raise ToolError("include_zero_byte 必须是 true 或 false")
    cutoff = time.time() - hours * 3600
    items: list[dict[str, Any]] = []
    if not RECORDINGS_ROOT.exists():
        return {"hours": hours, "count": 0, "files": [], "warning": "录制根目录不存在"}
    for path in RECORDINGS_ROOT.rglob("*"):
        if not path.is_file() or path.suffix.lower() not in VIDEO_SUFFIXES:
            continue
        if not _is_within(path, RECORDINGS_ROOT):
            continue
        try:
            info = path.stat()
        except OSError:
            continue
        if info.st_mtime < cutoff or (not include_zero_byte and info.st_size == 0):
            continue
        relative = path.relative_to(RECORDINGS_ROOT)
        if group and (not relative.parts or relative.parts[0] != group):
            continue
        items.append({
            "path": str(path),
            "relative_path": str(relative),
            "project_folder": relative.parts[0] if relative.parts else "",
            "in_compressed_folder": any("已压缩" in part for part in relative.parts),
            "size_bytes": info.st_size,
            "modified_at": datetime.fromtimestamp(info.st_mtime).astimezone().isoformat(timespec="seconds"),
            "zero_byte": info.st_size == 0,
        })
    items.sort(key=lambda item: item["modified_at"], reverse=True)
    return {"hours": hours, "count": len(items), "returned": min(len(items), limit), "files": items[:limit]}


def tool_validate_file(arguments: dict[str, Any]) -> dict[str, Any]:
    relative_path = _must_be_str(arguments.get("relative_path"), "relative_path", max_length=2000)
    candidate = (RECORDINGS_ROOT / relative_path).resolve()
    if not _is_within(candidate, RECORDINGS_ROOT):
        raise ToolError("只能核验直播录制视频目录内的文件")
    result: dict[str, Any] = {"relative_path": relative_path, "path": str(candidate), "exists": candidate.is_file()}
    if not candidate.is_file():
        result.update({"basic_valid": False, "reason": "文件不存在"})
        return result
    info = candidate.stat()
    age = max(0.0, time.time() - info.st_mtime)
    result.update({
        "size_bytes": info.st_size,
        "modified_at": datetime.fromtimestamp(info.st_mtime).astimezone().isoformat(timespec="seconds"),
        "suffix": candidate.suffix.lower(),
        "in_compressed_folder": any("已压缩" in part for part in candidate.relative_to(RECORDINGS_ROOT).parts),
        "basic_valid": candidate.suffix.lower() in VIDEO_SUFFIXES and info.st_size >= 1024,
        "stable_hint": age >= 120,
        "validation_scope": "仅核验文件存在、格式、大小与静置时长；未替代播放器或编码完整性验证。",
    })
    return result


def tool_get_reporting_policy(arguments: dict[str, Any]) -> dict[str, Any]:
    config = _read_json_file(REPORTER_CONFIG)
    wecom = config.get("wecom") if isinstance(config.get("wecom"), dict) else {}
    fault_alert = config.get("fault_alert") if isinstance(config.get("fault_alert"), dict) else {}
    return {
        "config_exists": REPORTER_CONFIG.exists(),
        "result_reporting": {
            "enabled": wecom.get("enabled"),
            "paused": wecom.get("paused"),
            "target_group_name": wecom.get("target_group_name"),
            "minimum_interval_hours": wecom.get("result_min_interval_hours"),
            "scheduled_time": wecom.get("result_schedule"),
        },
        "fault_reporting": {
            "enabled": fault_alert.get("enabled"),
            "paused": fault_alert.get("paused"),
            "unresolved_repeat_hours": fault_alert.get("repeat_unresolved_hours"),
        },
        "safety_rule": "此工具不会读取或返回机器人地址、令牌或其他凭据。",
    }


def tool_get_diagnostics(arguments: dict[str, Any]) -> dict[str, Any]:
    heartbeat = _read_json_file(MAINTENANCE_DIR / "watchdog_heartbeat.json")
    artifacts = []
    for relative in (
        Path("运行数据") / "maintenance" / "service-watchdog.log",
        Path("运行数据") / "maintenance" / "recording_health_watchdog.log",
        Path("运行数据") / "maintenance" / "watchdog_heartbeat.json",
    ):
        path = PROJECT_ROOT / relative
        artifacts.append({
            "path": str(path),
            "exists": path.exists(),
            "modified_at": datetime.fromtimestamp(path.stat().st_mtime).astimezone().isoformat(timespec="seconds") if path.exists() else None,
        })
    usage = None
    try:
        disk = shutil.disk_usage(RECORDINGS_ROOT)
        usage = {"free_bytes": disk.free, "total_bytes": disk.total, "used_bytes": disk.used}
    except OSError:
        pass
    return {
        "checked_at": _now_iso(),
        "watchdog_heartbeat": _redact(heartbeat),
        "artifacts": artifacts,
        "storage": usage,
        "note": "诊断不返回日志正文，避免将可能包含敏感地址的历史内容暴露给外部 AI。",
    }


TOOLS: dict[str, tuple[str, dict[str, Any], Any, bool]] = {
    "recording_get_status": (
        "读取本机录屏服务健康、全局设置摘要与当前正在录制的房间；不会改变任何状态。",
        {"type": "object", "properties": {}, "additionalProperties": False}, tool_get_status, True),
    "recording_list_rooms": (
        "按来源、项目、状态或关键词列出录屏房间。默认提供主页链接，不返回流地址或凭据。",
        {"type": "object", "properties": {
            "query": {"type": "string"}, "source_chat_id": {"type": "string"}, "source_chat_name": {"type": "string"},
            "group": {"type": "string"}, "status": {"type": "string"}, "enabled_only": {"type": "boolean"},
            "include_homepage_link": {"type": "boolean"}, "limit": {"type": "integer", "minimum": 1, "maximum": 200},
        }, "additionalProperties": False}, tool_list_rooms, True),
    "recording_get_room": (
        "读取一个指定录屏房间的任务、来源、目录和当前录制状态；不会改变任何状态。",
        {"type": "object", "properties": {"room_id": {"type": "string"}}, "required": ["room_id"], "additionalProperties": False}, tool_get_room, True),
    "recording_describe_routes": (
        "读取三条已配置来源到录屏/压缩目录的映射，便于其他 AI 在导入前校验归属。",
        {"type": "object", "properties": {}, "additionalProperties": False}, tool_describe_routes, True),
    "recording_import_rooms": (
        "从已映射来源导入抖音主页或直播间链接。默认仅预览；真实导入需 dry_run=false 与 confirm=true。",
        {"type": "object", "properties": {
            "text": {"type": "string"}, "url": {"type": "string"}, "source_chat_id": {"type": "string"},
            "source_chat_name": {"type": "string"}, "anchor": {"type": "string"}, "task_id": {"type": "string"},
            "group": {"type": "string"}, "submitted_url_raw": {"type": "string"}, "message_text": {"type": "string"},
            "raw_text": {"type": "string"}, "raw_message": {"type": "string"}, "monitor_enabled": {"type": "boolean"},
            "record_enabled": {"type": "boolean"}, "quality": {"type": "string"}, "record_mode": {"type": "string"},
            "max_minutes": {"type": "number"}, "split_minutes": {"type": "number"}, "auto_analyze": {"type": "boolean"},
            "dry_run": {"type": "boolean"}, "confirm": {"type": "boolean"},
        }, "additionalProperties": False}, tool_import_rooms, False),
    "recording_update_room": (
        "受控修改一个已有房间的名称、监控/录制开关和录制参数。不能改变来源和项目目录；需 confirm=true。",
        {"type": "object", "properties": {
            "room_id": {"type": "string"}, "display_name": {"type": "string"}, "manual_name": {"type": "string"},
            "monitor_enabled": {"type": "boolean"}, "record_enabled": {"type": "boolean"}, "quality": {"type": "string"},
            "record_mode": {"type": "string"}, "max_minutes": {"type": "number"}, "split_minutes": {"type": "number"},
            "auto_analyze": {"type": "boolean"}, "note": {"type": "string"}, "confirm": {"type": "boolean"},
        }, "required": ["room_id", "confirm"], "additionalProperties": False}, tool_update_room, False),
    "recording_control_room": (
        "刷新、立即开始或停止一个房间的录制。需要明确的用户授权和 confirm=true。",
        {"type": "object", "properties": {
            "room_id": {"type": "string"}, "action": {"type": "string", "enum": ["refresh", "start_recording", "stop_recording"]},
            "confirm": {"type": "boolean"},
        }, "required": ["room_id", "action", "confirm"], "additionalProperties": False}, tool_control_room, False),
    "recording_control_monitor": (
        "启动或停止整个录屏监控器。停止会影响所有房间，需明确用户授权和 confirm=true。",
        {"type": "object", "properties": {"action": {"type": "string", "enum": ["start", "stop"]}, "confirm": {"type": "boolean"}}, "required": ["action", "confirm"], "additionalProperties": False}, tool_control_monitor, False),
    "recording_update_settings": (
        "受控修改压缩、原片保留、分段和归档扫尾设置。不能改录制根目录、机器人地址或凭据；需 confirm=true。",
        {"type": "object", "properties": {
            "compress_recordings": {"type": "boolean"}, "compression_profile": {"type": "string"},
            "raw_retention": {"type": "string", "enum": ["move", "keep"]}, "segment_seconds": {"type": "number"},
            "archive_sweep_interval_seconds": {"type": "number"}, "confirm": {"type": "boolean"},
        }, "required": ["confirm"], "additionalProperties": False}, tool_update_settings, False),
    "recording_request_service_restart": (
        "请求现有看门狗在下一轮安全重启本机网页服务，不会另起第二套录屏进程；需 confirm=true。",
        {"type": "object", "properties": {"reason": {"type": "string"}, "confirm": {"type": "boolean"}}, "required": ["confirm"], "additionalProperties": False}, tool_request_service_restart, False),
    "recording_list_recent_files": (
        "按最近时间列出录屏和已压缩视频，支持检查零字节文件；不会移动或删除文件。",
        {"type": "object", "properties": {
            "hours": {"type": "number", "minimum": 1, "maximum": 336}, "limit": {"type": "integer", "minimum": 1, "maximum": 500},
            "group": {"type": "string"}, "include_zero_byte": {"type": "boolean"},
        }, "additionalProperties": False}, tool_list_recent_files, True),
    "recording_validate_file": (
        "核验录制根目录内一个视频的存在、大小、格式和静置状态；不会读取凭据或修改文件。",
        {"type": "object", "properties": {"relative_path": {"type": "string"}}, "required": ["relative_path"], "additionalProperties": False}, tool_validate_file, True),
    "recording_get_reporting_policy": (
        "读取结果汇报与故障提醒的频率设置，不返回企业微信机器人地址或任何凭据。",
        {"type": "object", "properties": {}, "additionalProperties": False}, tool_get_reporting_policy, True),
    "recording_get_diagnostics": (
        "读取看门狗心跳和诊断文件的新鲜度，不暴露日志正文、机器人地址或凭据。",
        {"type": "object", "properties": {}, "additionalProperties": False}, tool_get_diagnostics, True),
}


def _tool_definitions() -> list[dict[str, Any]]:
    result = []
    for name, (description, schema, _handler, read_only) in TOOLS.items():
        result.append({
            "name": name,
            "description": description,
            "inputSchema": schema,
            "annotations": {"readOnlyHint": read_only, "destructiveHint": False, "idempotentHint": read_only},
        })
    return result


def _handle_tool_call(params: Any) -> dict[str, Any]:
    data = _must_be_dict(params, "tools/call 参数")
    name = _must_be_str(data.get("name"), "工具名称")
    arguments = data.get("arguments", {})
    arguments = _must_be_dict(arguments, "工具参数")
    tool = TOOLS.get(name)
    if not tool:
        raise ToolError(f"未知工具：{name}")
    _description, _schema, handler, _read_only = tool
    result = handler(arguments)
    return {"content": [{"type": "text", "text": _json_text(result)}], "isError": False}


def _response(request_id: Any, result: Any = None, error: dict[str, Any] | None = None) -> dict[str, Any]:
    message: dict[str, Any] = {"jsonrpc": "2.0", "id": request_id}
    if error is not None:
        message["error"] = error
    else:
        message["result"] = result
    return message


def _dispatch(message: Any) -> dict[str, Any] | None:
    if not isinstance(message, dict) or message.get("jsonrpc") != "2.0":
        return _response(None, error={"code": -32600, "message": "无效的 JSON-RPC 请求"})
    method = message.get("method")
    request_id = message.get("id")
    if not isinstance(method, str):
        return _response(request_id, error={"code": -32600, "message": "缺少 method"})
    if method == "notifications/initialized":
        return None
    if method == "initialize":
        return _response(request_id, {
            "protocolVersion": "2024-11-05",
            "capabilities": {"tools": {}},
            "serverInfo": {"name": SERVER_NAME, "version": SERVER_VERSION},
            "instructions": "本机录屏工具。先查询状态；任何会修改录屏状态的调用均需用户明确同意并传 confirm=true。",
        })
    if method == "tools/list":
        return _response(request_id, {"tools": _tool_definitions()})
    if method == "tools/call":
        try:
            return _response(request_id, _handle_tool_call(message.get("params", {})))
        except ToolError as exc:
            return _response(request_id, {"content": [{"type": "text", "text": str(exc)}], "isError": True})
        except Exception:
            return _response(request_id, {"content": [{"type": "text", "text": "工具执行失败；请检查本机录屏服务与工具日志。"}], "isError": True})
    return _response(request_id, error={"code": -32601, "message": f"不支持的方法：{method}"})


def _read_messages() -> Any:
    global OUTPUT_WITH_HEADERS
    stream = sys.stdin.buffer
    while True:
        first = stream.readline()
        if not first:
            return
        if not first.strip():
            continue
        if first.lower().startswith(b"content-length:"):
            OUTPUT_WITH_HEADERS = True
            try:
                length = int(first.split(b":", 1)[1].strip())
            except (IndexError, ValueError):
                continue
            while True:
                header = stream.readline()
                if not header or header in {b"\r\n", b"\n"}:
                    break
            payload = stream.read(length)
        else:
            payload = first
        try:
            yield json.loads(payload.decode("utf-8"))
        except (UnicodeDecodeError, json.JSONDecodeError):
            yield {"jsonrpc": "2.0", "id": None, "method": "__invalid__"}


def _write_message(message: dict[str, Any]) -> None:
    payload = json.dumps(message, ensure_ascii=False, separators=(",", ":")).encode("utf-8")
    if OUTPUT_WITH_HEADERS:
        sys.stdout.buffer.write(f"Content-Length: {len(payload)}\r\n\r\n".encode("ascii"))
        sys.stdout.buffer.write(payload)
    else:
        sys.stdout.buffer.write(payload + b"\n")
    sys.stdout.buffer.flush()


def main() -> int:
    for message in _read_messages():
        answer = _dispatch(message)
        if answer is not None:
            _write_message(answer)
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
