---
name: live-recording-control
description: Use when an AI needs to inspect, import, adjust, or safely operate the local AIFUPAN live-recording workbench on this Windows computer.
---

# 本机直播录屏工作台

此工具只连接本机的直播录制工作台，不会启动第二套录屏服务。

## 使用顺序

1. 先调用 `recording_get_status`，确认本机服务可用、当前录制和压缩设置。
2. 导入任务前先调用 `recording_describe_routes`，再用 `recording_import_rooms` 的预览模式核对来源、项目和目录。
3. 只有用户明确授权后，才用 `dry_run=false` 与 `confirm=true` 真正导入或修改录制参数。
4. 对单个房间的启停、全局监控启停、服务重启和设置修改，都要先说明影响并取得明确确认。
5. 每次实际修改后，回读对应状态或房间，报告真实结果与目录；不能只根据调用返回文字就声称录制已成功。

## 固定安全边界

- 不读取、输出、写入或修改 cookie、token、secret、机器人地址、飞书授权或企业微信凭据。
- 不移动、删除、重命名历史视频，也不提供批量删除工具。
- 不接收任意输出目录；只有已经配置来源映射的任务可以导入，避免落入默认目录或混到其他项目。
- 不改变来源、项目路由或任务的录屏/压缩目录；若需要迁移，交由本机管理员按专项流程处理。
- 所有本机网页服务动作均走已有的 127.0.0.1:8765 服务和既有看门狗，不另起服务链。

## 文件与状态核验

- 使用 `recording_list_recent_files` 查最近落盘文件；零字节文件必须作为异常报告，不得当作成功。
- 使用 `recording_validate_file` 只能确认文件存在、大小、扩展名和静置状态，不等于视频内容可完整播放。
- `recording_get_room` 的 `recording_valid` 与实际文件路径均应核对后，才能说明一段录制已经完成。

## 报告要求

报告时区分“已导入”“正在录制”“已完成并通过基础文件核验”“需人工处理”。
不要把状态查询、事件落盘、窗口在线或测试事件写成真实录制完成。
