﻿# AIFUPAN 直播录制工作台 · MCP 工具包（便携版）

给同一台 Windows 电脑上的 AI 工具使用的本机 MCP 接入包。它通过录屏服务接口访问工作台，提供房间查询、来源分目录导入、受控参数调整、录制状态与文件核验等能力。

## 前置条件
- 先运行上一层的「启动录屏工作台.vbs」，让录制引擎在 `127.0.0.1:8765` 就绪。
- 本机已安装 Python 3.9+ 且在 PATH 中（`mcp.json` 的命令为 `python`）。若你的 Python 命令是 `python3` 或绝对路径，请相应修改 `mcp.json` 的 `command`。

## 接入方式
把本 `mcp/` 目录作为本地插件导入支持 MCP 的 AI 工具。插件描述是 `plugin.json`，MCP 连接配置是 `mcp.json`。

## 安全设计
- 读取类工具默认只读。
- 会改变状态的工具必须显式 `confirm=true`；导入默认仅预览。
- 不暴露或修改 cookie、token、机器人地址、流地址等凭据。
- 不提供删除/移动/重命名历史录屏的接口。
- 只接入本机已存在的 `127.0.0.1:8765` 服务。

## 使用建议
先让 AI 用 `recording_get_status`、`recording_describe_routes` 做只读检查，再按 `skills/live-recording-control/SKILL.md` 的确认规则执行操作。
